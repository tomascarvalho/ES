from server import start_server
if __name__ == '__main__':
    start_server()